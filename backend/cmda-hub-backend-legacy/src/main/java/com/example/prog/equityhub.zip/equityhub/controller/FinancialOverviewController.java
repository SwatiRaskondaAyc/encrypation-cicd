package com.example.prog.equityhub.controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/financial")
public class FinancialOverviewController {

    @Autowired
    @Qualifier("accordJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    @GetMapping("fin_ov/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getFinancialDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME, fo.* " +
                     "FROM vw_financials_overview fo " +
                     "JOIN Company_master cm ON fo.FINCODE = cm.FINCODE " +
                     "WHERE cm.SYMBOL = ?";

        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
    
    @GetMapping("balance_sheet/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getBalanceSheetDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.* " +
                     "FROM vw_balance_sheet fo " +
                     "join Company_master cm on fo.FINCODE = cm.FINCODE " +
                     "WHERE cm.SYMBOL = ?";
        

        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
    
    
    @GetMapping("income_state/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getIncomeSateDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.* " +
                     "FROM vw_income_statement fo " +
                     "join Company_master cm on fo.FINCODE = cm.FINCODE " +
                     "WHERE cm.SYMBOL = ?";

        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
    
    @GetMapping("CashFlow_state/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getCashFlowStateDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.* " +
                     "FROM vw_cash_flow_statement fo " +
                     "join Company_master cm on fo.FINCODE = cm.FINCODE " +
                     "WHERE cm.SYMBOL = ?";
        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
    
    
    @GetMapping("financial_ratios/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getFinancialRatiosDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.* " +
                     "FROM vw_financial_ratios fo " +
                     "join Company_master cm on fo.FINCODE = cm.FINCODE " +
                     "WHERE cm.SYMBOL = ?";

        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
      
    
}
