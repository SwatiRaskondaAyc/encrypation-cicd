package com.example.prog.equityhub.controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/Shareholding")
public class ShareHoldingController {

	@Autowired
	@Qualifier("accordJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@GetMapping("summary/{symbol}")
	public ResponseEntity<List<Map<String, Object>>> getShareDataBySymbol(@PathVariable String symbol) {
		String sql = "SELECT shp.* " +
				"FROM Share_Holding_Patterns shp " +
				"INNER JOIN ( " +
				   " SELECT Fincode, MAX(DATE_END) AS MaxDate " +
				   " FROM Share_Holding_Patterns " +
				   " GROUP BY Fincode" +
				" ) latest " +
				" ON shp.Fincode = latest.Fincode " +
				" AND shp.DATE_END = latest.MaxDate " +
				" WHERE Symbol = ? " ;
		try {
			List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
			return ResponseEntity.ok(result);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Collections.singletonList(Map.of("error",e.getMessage())));
		}	
	}
	
	@GetMapping("Overall/{symbol}")
	public ResponseEntity<List<Map<String, Object>>> getShareOvDataBySymbol(@PathVariable String symbol) {
		String sql = "WITH RankedData AS ("
				+ "    SELECT *, "
				+ "           ROW_NUMBER() OVER (PARTITION BY Fincode ORDER BY DATE_END DESC) AS rn "
				+ "    FROM Share_Holding_Patterns "
				+ ") "
				+ "SELECT * "
				+ "FROM RankedData "
				+ "WHERE rn <= 5 AND Symbol = ? "
				+ "ORDER BY Fincode, DATE_END DESC";
		
		try {
			List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
			return ResponseEntity.ok(result);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Collections.singletonList(Map.of("error",e.getMessage())));
		}	
	}
	
}
