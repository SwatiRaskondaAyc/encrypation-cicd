package com.example.prog.equityhub.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.example.prog.datasource.service.PortfolioService;
import com.example.prog.entity.CorporateUser;
import com.example.prog.entity.UserDtls;
import com.example.prog.equityhub.repo.ListedSecuritiesRepository;
import com.example.prog.equityhub.service.SearchService;
import com.example.prog.repository.CorporateUserRepository;
import com.example.prog.repository.UserRepository;
import com.example.prog.repository.equitydatafetchRepo.EquityPlotFetchRepo;
import com.example.prog.token.JwtUtil;

import jakarta.servlet.http.HttpSession;

import org.springframework.web.client.HttpClientErrorException;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;


@RestController
@RequestMapping("/api/stocks/test")
public class EquityHubController {

    @Autowired
    private CorporateUserRepository corporateUserRepository;

    @Autowired
    private EquityPlotFetchRepo userStockActionRepository;

    @Autowired
    private SearchService stockService;

    @Autowired
    private HttpSession httpSession;

    @Autowired
    private JwtUtil jwtUtil; // Inject JwtUtil

    private final ListedSecuritiesRepository listedSecuritiesRepository;
    private final PortfolioService portfolioService;
    private final UserRepository userRepository;
//"http://127.0.0.1:3000/
    @Value("${fastapi.service.url:http://app:3000}")
    private String fastApiBaseUrl;

    private static final Logger logger = LoggerFactory.getLogger(EquityHubController.class);

    public EquityHubController(ListedSecuritiesRepository listedSecuritiesRepository,
                            PortfolioService portfolioService,
                            UserRepository userRepository) {
        this.listedSecuritiesRepository = listedSecuritiesRepository;
        this.portfolioService = portfolioService;
        this.userRepository = userRepository;
    }

    // Extract user details from JWT token
    private Map<String, Object> extractUserDetailsFromToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new RuntimeException("Missing or invalid Authorization header");
        }

        String jwtToken = authHeader.substring(7);
        String email = jwtUtil.extractEmail(jwtToken);

        CorporateUser corporateUser = corporateUserRepository.findByemail(email);
        if (corporateUser != null) {
            Map<String, Object> userDetails = new HashMap<>();
            userDetails.put("email", email);
            userDetails.put("userType", "corporate");
            userDetails.put("userId", corporateUser.getId());
            return userDetails;
        }

        Optional<UserDtls> individualUserOpt = userRepository.findByEmail(email);
        if (individualUserOpt.isPresent()) {
            UserDtls individualUser = individualUserOpt.get();
            Map<String, Object> userDetails = new HashMap<>();
            userDetails.put("email", email);
            userDetails.put("userType", "individual");
            userDetails.put("userId", individualUser.getUserID());
            return userDetails;
        }

        throw new RuntimeException("User not found for email: " + email);
    }

    // Fetch user's saved stocks
    @GetMapping("/saved")
    public ResponseEntity<List<Map<String, Object>>> getSavedStocks(HttpServletRequest request) {
        try {
            Map<String, Object> userDetails = extractUserDetailsFromToken(request);
            String email = (String) userDetails.get("email");
            String userType = (String) userDetails.get("userType");
            Integer userId = (Integer) userDetails.get("userId");

            return ResponseEntity.ok(stockService.getSavedStocks(userType, userId, email));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Collections.emptyList());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.emptyList());
        }
    }

    // Save a stock
    @PostMapping("/saveStock")
    public ResponseEntity<String> saveStock(
            @RequestBody Map<String, String> requestBody,
            HttpServletRequest request) {
        try {
            Map<String, Object> userDetails = extractUserDetailsFromToken(request);
            String email = (String) userDetails.get("email");
            String userType = (String) userDetails.get("userType");
            Integer userId = (Integer) userDetails.get("userId");

            String symbol = requestBody.get("symbol");
            String companyName = requestBody.get("companyName");

            return stockService.saveStock(userType, userId, email, symbol, companyName);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving stock");
        }
    }

    // Search for stocks without requiring authentication
    @GetMapping("/search")
    public ResponseEntity<List<Map<String, String>>> searchStocks(
            @RequestParam String query) {
        try {
            return ResponseEntity.ok(stockService.searchStocks(query, false, null, null, null));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.emptyList());
        }
    }

    // Delete a saved stock
    @DeleteMapping("/delete")
    public ResponseEntity<Map<String, String>> deleteSavedStock(
            @RequestBody Map<String, String> requestBody,
            HttpServletRequest request) {
        try {
            Map<String, Object> userDetails = extractUserDetailsFromToken(request);
            String email = (String) userDetails.get("email");
            String userType = (String) userDetails.get("userType");
            Integer userID = (Integer) userDetails.get("userId");

            String symbol = requestBody.get("symbol");
            String companyName = requestBody.get("companyName");

            return stockService.deleteSavedStock(userType, userID, email, symbol, companyName);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Unexpected error occurred while deleting stock"));
        }
    }

    @PostMapping("/compute_public_trading_activity")
    public ResponseEntity<Map<String, Object>> computePublicTradingActivity(@RequestBody Map<String, String> stockData) {
        return generatePlotWithoutFastApi(stockData.get("symbol"), stockData.get("companyName"), "compute_public_trading_activity");
    }
    
    private ResponseEntity<Map<String, Object>> generatePlotWithoutFastApi(String symbol, String companyName, String plotType) {
        String formattedSymbol = symbol + " - " + companyName;
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                    // "python", "src/main/resources/scripts/generate_plot.py", plotType, formattedSymbol
                    "python3", "/app/PythonScript/EquityHub_Scripts/generate_plot.py", plotType, formattedSymbol
            );
            processBuilder.redirectErrorStream(false); // Keep stdout and stderr separate
            Process process = processBuilder.start();

            // Capture stdout (JSON output)
            BufferedReader stdoutReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = stdoutReader.readLine()) != null) {
                output.append(line);
            }

            // Capture stderr (for debugging)
            BufferedReader stderrReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            StringBuilder errorOutput = new StringBuilder();
            while ((line = stderrReader.readLine()) != null) {
                errorOutput.append(line).append("\n");
            }

            int exitCode = process.waitFor();
            if (exitCode != 0) {
                System.err.println("Python script stderr: " + errorOutput.toString());
                return ResponseEntity.status(500).body(Map.of("error", "Python script failed with exit code: " + exitCode + "\nError: " + errorOutput.toString()));
            }

            // Validate JSON before parsing
            String jsonString = output.toString().trim();
            if (jsonString.isEmpty()) {
                return ResponseEntity.status(500).body(Map.of("error", "Empty output from Python script"));
            }
            if (!jsonString.startsWith("{")) {
                System.err.println("Invalid JSON output: " + jsonString);
                return ResponseEntity.status(500).body(Map.of("error", "Invalid JSON output from Python script: " + jsonString));
            }

            JSONObject jsonResponse = new JSONObject(jsonString);
            return ResponseEntity.ok(jsonResponse.toMap());

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
    }

    @PostMapping("/candle_chronicle")
    public ResponseEntity<Map<String, Object>> processStock(@RequestBody Map<String, String> stockData) {
        String symbol = stockData.get("symbol");
        String companyName = stockData.get("companyName");
        String figType = stockData.get("fig_type"); // Extract fig_type from request body
        return generateCandlrPlot(symbol, companyName, figType, "candle_chronicle");
    }

    private ResponseEntity<Map<String, Object>> generateCandlrPlot(String symbol, String companyName, String figType, String plotType) {
    try {
        // FastAPI full endpoint with /plot_generation
        RestTemplate restTemplate = new RestTemplate();
        
        // Construct URL properly
        String url = fastApiBaseUrl + "/plot_generation"
            + "?symbol=" + URLEncoder.encode(symbol, StandardCharsets.UTF_8)
            + "&period=TTM"
            + "&plot_type=" + URLEncoder.encode(plotType, StandardCharsets.UTF_8)
            + "&fig=" + URLEncoder.encode(figType, StandardCharsets.UTF_8);

        // GET request
        @SuppressWarnings("unchecked")
        Map<String, Object> response = restTemplate.getForObject(url, Map.class);

        if (response == null || response.containsKey("error")) {
            return ResponseEntity.status(500).body(Map.of("error", "FastAPI error: " + (response != null ? response.get("error") : "Unknown error")));
        }

        // Add company name
        response.put("companyName", companyName);
        return ResponseEntity.ok(response);

    } catch (Exception e) {
        return ResponseEntity.status(500).body(Map.of("error", "Failed to generate plot: " + e.getMessage()));
    }
}

    @PostMapping("/breach_busters")
    public ResponseEntity<Map<String, Object>> candleBreach(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "breach_busters");
    }
    
    @PostMapping("/price_trend")
    public ResponseEntity<Map<String, Object>> price_trend(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "price_trend");
    }
    
    @PostMapping("/trend_tapestry")
    public ResponseEntity<Map<String, Object>> trendTapestry(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "trend_tapestry");
    }
    
    @PostMapping("/macd")
    public ResponseEntity<Map<String, Object>> macd(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "macd");
    }
    
    @PostMapping("/sensex_stock_fluctuations")
    public ResponseEntity<Map<String, Object>> SensexStockFluctuations(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "sensex_stock_fluctuations");
    }

    @PostMapping("/sensex_symphony")
    public ResponseEntity<Map<String, Object>> SensexSymphony(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "sensex_symphony");
    }
    
    @PostMapping("/performance_heatmap")
    public ResponseEntity<Map<String, Object>> PerformanceHeatmap(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "performance_heatmap");
    }
    
    @PostMapping("/pe_eps_book_value")
    public ResponseEntity<Map<String, Object>> PeEpsBookValue(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "pe_eps_book_value");
    }
    
    @PostMapping("/box_plot")
    public ResponseEntity<Map<String, Object>> BoxPlot(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "box_plot");
    }
    
    
    @PostMapping("/market_mood")
    public ResponseEntity<Map<String, Object>> MarketMood(@RequestBody Map<String, String> stockData) {
        return generatePlot(stockData.get("symbol"), stockData.get("companyName"), "market_mood");
    }
    
    
    
    @PostMapping("/generate_prediction")
    public ResponseEntity<Map<String, Object>> generatePrediction(
            @RequestBody Map<String, String> requestBody) {
        try {
            String symbol = requestBody.get("symbol");
            String companyName = requestBody.get("companyName");
            return stockService.generatePrediction(symbol, companyName);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
    }

    @PostMapping("/generate_values")
    public ResponseEntity<Map<String, Object>> generateValues(
            @RequestBody Map<String, String> requestBody) {
        try {
            String symbol = requestBody.get("symbol");
            String companyName = requestBody.get("companyName");

            // Call the service method without user info and shouldSave
            return generateValues(symbol, companyName);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
    }

    private ResponseEntity<Map<String, Object>> generateValues(String symbol, String companyName) {
    	try {
            RestTemplate restTemplate = new RestTemplate();
            String formattedSymbol = symbol.toUpperCase();
            String url = String.format("%s/load_data?symbol=%s",
                    fastApiBaseUrl, formattedSymbol);

            // Make HTTP GET request to FastAPI
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> responseBody = response.getBody();
                if (responseBody != null && "success".equals(responseBody.get("status"))) {
                    return ResponseEntity.ok((Map<String, Object>) responseBody.get("data"));
                } else {
                    String errorMsg = responseBody != null ? (String) responseBody.get("message") : "Unknown error from FastAPI";
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(Map.of("error", errorMsg));
                }
            } else {
                return ResponseEntity.status(response.getStatusCode())
                        .body(Map.of("error", "FastAPI returned non-200 status: " + response.getStatusCodeValue()));
            }
        } catch (HttpClientErrorException e) {
            return ResponseEntity.status(e.getStatusCode())
                    .body(Map.of("error", "FastAPI error: " + e.getResponseBodyAsString()));
        } catch (Exception e) {
            logger.error("Error calling FastAPI for plot generation: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
	}

    private ResponseEntity<Map<String, Object>> generatePlot(String symbol, String companyName, String plotType) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            String formattedSymbol = symbol.toUpperCase();
            String url = String.format("%s/plot_generation?symbol=%s&plot_type=%s&period=TTM",
                    fastApiBaseUrl, formattedSymbol, plotType);

            // Make HTTP GET request to FastAPI
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> responseBody = response.getBody();
                if (responseBody != null && "success".equals(responseBody.get("status"))) {
                    return ResponseEntity.ok((Map<String, Object>) responseBody.get("data"));
                } else {
                    String errorMsg = responseBody != null ? (String) responseBody.get("message") : "Unknown error from FastAPI";
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(Map.of("error", errorMsg));
                }
            } else {
                return ResponseEntity.status(response.getStatusCode())
                        .body(Map.of("error", "FastAPI returned non-200 status: " + response.getStatusCodeValue()));
            }
        } catch (HttpClientErrorException e) {
            return ResponseEntity.status(e.getStatusCode())
                    .body(Map.of("error", "FastAPI error: " + e.getResponseBodyAsString()));
        } catch (Exception e) {
            logger.error("Error calling FastAPI for plot generation: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
    }
}