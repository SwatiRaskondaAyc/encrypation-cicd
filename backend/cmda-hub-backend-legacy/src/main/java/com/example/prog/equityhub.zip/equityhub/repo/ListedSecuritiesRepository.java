package com.example.prog.equityhub.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.prog.equityhub.entity.ListedSecurities;

import java.util.List;

@Repository
public interface ListedSecuritiesRepository extends JpaRepository<ListedSecurities, String> {
	@Query("SELECT DISTINCT h.symbol, l.companyName, i.basicIndustry " +
		       "FROM HistPA h " +
		       "LEFT JOIN ListedSecurities l ON l.symbol = h.symbol " +
		       "JOIN IndustryStructure i ON i.basicIndCode = l.basicIndCode " +
		       "WHERE h.symbol LIKE :query%")
		List<Object[]> findBySymbolOrCompanyName(@Param("query") String query);    
}   




