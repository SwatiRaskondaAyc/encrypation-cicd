package com.example.prog.equityhub.controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/consolidate")
public class FinConsolidateController {
	
	@Autowired
	@Qualifier("accordJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@GetMapping("overview/{symbol}")
	public ResponseEntity<List<Map<String, Object>>> getStandFinDataBySymbol(@PathVariable String symbol) {
		String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.* "
				+ "FROM vw_financials_overview_cons fo "
				+ "join Company_master cm on fo.FINCODE = cm.FINCODE "
				+ "WHERE cm.SYMBOL = ? ";
		
		try {
			List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
			return ResponseEntity.ok(result);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Collections.singletonList(Map.of("error",e.getMessage())));
		}	
	}
	
	@GetMapping("balance_sheet/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getStandBalanceSheetDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.* " +
        		" FROM vw_balance_sheet_cons fo " +
        		" join Company_master cm on fo.FINCODE = cm.FINCODE " +
        		" WHERE cm.SYMBOL = ? ";
        

        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
	
    @GetMapping("income_state/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getStandIncomeSateDataBySymbol(@PathVariable String symbol) {
        String sql ="SELECT cm.SYMBOL, cm.COMPNAME,  fo.* " +  
        		"FROM vw_income_statement_cons fo " +
        		"join Company_master cm on fo.FINCODE = cm.FINCODE " +
        		"WHERE cm.SYMBOL = ? ";
        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
    
    @GetMapping("CashFlow_state/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getStandCashFlowStateDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.* " +
        		"FROM vw_cash_flow_statement_cons fo " +
        		"join Company_master cm on fo.FINCODE = cm.FINCODE "+
        		"WHERE cm.SYMBOL = ? ";
        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }
    
    @GetMapping("financial_ratios/{symbol}")
    public ResponseEntity<List<Map<String, Object>>> getStandFinancialRatiosDataBySymbol(@PathVariable String symbol) {
        String sql = "SELECT cm.SYMBOL, cm.COMPNAME,  fo.*  " +
        		"FROM vw_financial_ratios_cons fo " +
        		"join Company_master cm on fo.FINCODE = cm.FINCODE " +
        		"WHERE cm.SYMBOL = ? ";

        try {
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, symbol);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList(Map.of("error", e.getMessage())));
        }
    }

}
