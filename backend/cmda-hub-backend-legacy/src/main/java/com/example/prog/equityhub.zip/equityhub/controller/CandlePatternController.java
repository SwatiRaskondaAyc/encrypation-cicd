package com.example.prog.equityhub.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.prog.equityhub.service.CandlePatternService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/candle-patterns")
public class CandlePatternController {

    @Autowired
    private CandlePatternService candlePatternService;

    @PostMapping
    public ResponseEntity<Map<String, Object>> getCandlePatterns(@RequestBody Map<String, String> stockData) {
    	System.out.println("Received symbol: " + stockData.get("symbol"));
        return candlePatternService.getCandlePatterns(stockData.get("symbol"));
    }
}
