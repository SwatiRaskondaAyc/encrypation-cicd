package com.example.prog.equityhub.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.prog.entity.equityDataFetch.EquityPlotFetch;
import com.example.prog.equityhub.repo.ListedSecuritiesRepository;
import com.example.prog.equityhub.service.SearchService;
import com.example.prog.repository.equitydatafetchRepo.EquityPlotFetchRepo;

import org.springframework.web.client.HttpClientErrorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class EquityHubServiceImpl implements SearchService {

    private static final Logger logger = LoggerFactory.getLogger(EquityHubServiceImpl.class);

    @Autowired
    private EquityPlotFetchRepo equityPlotFetchRepository;

    @Autowired
    private ListedSecuritiesRepository listedSecuritiesRepository;

    @Value("${fastapi.service.url:http://127.0.0.1:8000}")
    private String fastApiBaseUrl;

    @Override
    public List<Map<String, Object>> getSavedStocks(String userType, Integer userId, String email) {
        logger.info("Fetching saved stocks for UserID: {}, UserType: {}, Email: {}", userId, userType, email);

        List<EquityPlotFetch> savedStocks = equityPlotFetchRepository.findByUserTypeAndUserID(userType, userId);

        List<Map<String, Object>> results = new ArrayList<>();
        for (EquityPlotFetch stock : savedStocks) {
            Map<String, Object> stockData = new HashMap<>();
            stockData.put("userID", stock.getUserID());
            stockData.put("userType", stock.getUserType());
            stockData.put("symbol", stock.getSymbol());
            stockData.put("companyName", stock.getCompanyName());
            stockData.put("updatedAt", stock.getUpdatedAt().toString());
            results.add(stockData);
        }

        logger.info("Retrieved {} saved stocks for UserID: {}", results.size(), userId);
        return results;
    }

    @Override
    public List<Map<String, String>> searchStocks(String query, boolean shouldSave, String userType, Integer userId, String email) {
        logger.info("Search request - UserID: {}, UserType: {}, Email: {}, Query: {}, shouldSave: {}",
                userId, userType, email, query, shouldSave);

        List<Map<String, String>> results = new ArrayList<>();
        List<Object[]> stockData = listedSecuritiesRepository.findBySymbolOrCompanyName(query);

        for (Object[] record : stockData) {
            String symbol = (String) record[0];
            String companyName = (String) record[1];
            String basicIndustry = (String) record[2];

            if (symbol == null || companyName == null || symbol.isEmpty() || companyName.isEmpty()) {
                logger.warn("Invalid stock data for query: {}, symbol: {}, companyName: {}", query, symbol, companyName);
                continue;
            }

            if (shouldSave) {
                EquityPlotFetch action = getOrSaveUserStockAction(userType, userId, symbol, companyName, true);
                if (action == null) {
                    logger.error("Failed to save stock action for user: {}, symbol: {}, companyName: {}",
                            userId, symbol, companyName);
                }
            }

            Map<String, String> stock = new HashMap<>();
            stock.put("symbol", symbol);
            stock.put("companyName", companyName);
            stock.put("basicIndustry", basicIndustry);
            results.add(stock);
        }

        return results;
    }

    @Override
    public ResponseEntity<Map<String, String>> deleteSavedStock(String userType, Integer userID, String email, String symbol, String companyName) {
        if (symbol == null || companyName == null || symbol.isEmpty() || companyName.isEmpty()) {
            logger.warn("Missing or empty symbol or companyName in delete request for UserID: {}", userID);
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Missing or empty symbol or companyName"));
        }

        logger.info("Delete request - UserID: {}, UserType: {}, Email: {}, Symbol: {}, CompanyName: {}",
                userID, userType, email, symbol, companyName);

        Optional<EquityPlotFetch> existingActionOpt = equityPlotFetchRepository
                .findByUserTypeAndUserIDAndSymbolAndCompanyName(userType, userID, symbol, companyName);

        if (!existingActionOpt.isPresent()) {
            logger.warn("Stock action not found for deletion - UserID: {}, Symbol: {}, CompanyName: {}",
                    userID, symbol, companyName);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Stock not found in saved list"));
        }

        EquityPlotFetch stockToDelete = existingActionOpt.get();
        equityPlotFetchRepository.delete(stockToDelete);

        logger.info("Successfully deleted stock action for UserID: {}, Symbol: {}, CompanyName: {}",
                userID, symbol, companyName);

        return ResponseEntity.ok(Map.of("message", "Stock successfully deleted from saved list"));
    }

    @Override
    public ResponseEntity<Map<String, Object>> generateValues(String symbol, String companyName) {
        logger.info("Generating values for Symbol: {}, CompanyName: {}", symbol, companyName);

        if (symbol == null || companyName == null || symbol.isEmpty() || companyName.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Missing or empty symbol or companyName"));
        }

        try {
            RestTemplate restTemplate = new RestTemplate();
            String formattedSymbol = symbol.toUpperCase();
            String url = String.format("%s/generate_values?symbols=%s", fastApiBaseUrl, formattedSymbol);

            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> responseBody = response.getBody();
                if (responseBody != null && "success".equals(responseBody.get("status"))) {
                    return ResponseEntity.ok((Map<String, Object>) responseBody.get("data"));
                } else {
                    String errorMsg = responseBody != null ? (String) responseBody.get("message") : "Unknown error from FastAPI";
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(Map.of("error", errorMsg));
                }
            } else {
                return ResponseEntity.status(response.getStatusCode())
                        .body(Map.of("error", "FastAPI returned non-200 status: " + response.getStatusCodeValue()));
            }
        } catch (HttpClientErrorException e) {
            logger.error("FastAPI error for generateValues: {}", e.getResponseBodyAsString());
            return ResponseEntity.status(e.getStatusCode())
                    .body(Map.of("error", "FastAPI error: " + e.getResponseBodyAsString()));
        } catch (Exception e) {
            logger.error("Error calling FastAPI for generateValues: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> generatePrediction(String symbol, String companyName) {
        logger.info("Generating prediction for Symbol: {}, CompanyName: {}", symbol, companyName);

        if (symbol == null || companyName == null || symbol.isEmpty() || companyName.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Missing or empty symbol or companyName"));
        }

        try {
            RestTemplate restTemplate = new RestTemplate();
            String formattedSymbol = symbol.toUpperCase();
            String url = String.format("%s/generate_prediction?symbols=%s", fastApiBaseUrl, formattedSymbol);

            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> responseBody = response.getBody();
                if (responseBody != null && "success".equals(responseBody.get("status"))) {
                    return ResponseEntity.ok((Map<String, Object>) responseBody.get("data"));
                } else {
                    String errorMsg = responseBody != null ? (String) responseBody.get("message") : "Unknown error from FastAPI";
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(Map.of("error", errorMsg));
                }
            } else {
                return ResponseEntity.status(response.getStatusCode())
                        .body(Map.of("error", "FastAPI returned non-200 status: " + response.getStatusCodeValue()));
            }
        } catch (HttpClientErrorException e) {
            logger.error("FastAPI error for generatePrediction: {}", e.getResponseBodyAsString());
            return ResponseEntity.status(e.getStatusCode())
                    .body(Map.of("error", "FastAPI error: " + e.getResponseBodyAsString()));
        } catch (Exception e) {
            logger.error("Error calling FastAPI for generatePrediction: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> generatePlot(String symbol, String companyName, String plotType) {
        logger.info("Generating plot for Symbol: {}, CompanyName: {}, PlotType: {}", symbol, companyName, plotType);

        if (symbol == null || companyName == null || symbol.isEmpty() || companyName.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Missing or empty symbol or companyName"));
        }

        try {
            RestTemplate restTemplate = new RestTemplate();
            String formattedSymbol = symbol.toUpperCase();
            String url = String.format("%s/plot_generation?symbols=%s&plot_type=%s&period=TTM",
                    fastApiBaseUrl, formattedSymbol, plotType);

            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> responseBody = response.getBody();
                if (responseBody != null && "success".equals(responseBody.get("status"))) {
                    return ResponseEntity.ok((Map<String, Object>) responseBody.get("data"));
                } else {
                    String errorMsg = responseBody != null ? (String) responseBody.get("message") : "Unknown error from FastAPI";
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(Map.of("error", errorMsg));
                }
            } else {
                return ResponseEntity.status(response.getStatusCode())
                        .body(Map.of("error", "FastAPI returned non-200 status: " + response.getStatusCodeValue()));
            }
        } catch (HttpClientErrorException e) {
            logger.error("FastAPI error for plot generation: {}", e.getResponseBodyAsString());
            return ResponseEntity.status(e.getStatusCode())
                    .body(Map.of("error", "FastAPI error: " + e.getResponseBodyAsString()));
        } catch (Exception e) {
            logger.error("Error calling FastAPI for plot generation: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error processing stock data: " + e.getMessage()));
        }
    }

    @Override
    public EquityPlotFetch getOrSaveUserStockAction(String userType, Integer userId, String symbol, String companyName, boolean shouldSave) {
        Optional<EquityPlotFetch> existingActionOpt = equityPlotFetchRepository
                .findByUserTypeAndUserIDAndSymbolAndCompanyName(userType, userId, symbol, companyName);

        if (existingActionOpt.isPresent()) {
            EquityPlotFetch existingAction = existingActionOpt.get();
            logger.info("Existing stock action found for user: {}, symbol: {}, companyName: {}",
                    userId, symbol, companyName);

            if (shouldSave) {
                existingAction.setUpdatedAt(LocalDateTime.now());
                equityPlotFetchRepository.save(existingAction);
                logger.info("Updated existing stock action timestamp for user: {}, symbol: {}, companyName: {}",
                        userId, symbol, companyName);
            }

            return existingAction;

        } else {
            if (shouldSave) {
                EquityPlotFetch action = new EquityPlotFetch();
                action.setUserType(userType);
                action.setUserID(userId);
                action.setSymbol(symbol);
                action.setCompanyName(companyName);
                action.setUpdatedAt(LocalDateTime.now());
                equityPlotFetchRepository.save(action);
                logger.info("Saved new stock action for user: {}, symbol: {}, companyName: {}",
                        userId, symbol, companyName);
                return action;
            } else {
                logger.info("User chose not to save stock action for: {}, symbol: {}, companyName: {}",
                        userId, symbol, companyName);
                return null;
            }
        }
    }

    @Override
    public ResponseEntity<String> saveStock(String userType, Integer userId, String email, String symbol, String companyName) {
        if (symbol == null || companyName == null || symbol.isEmpty() || companyName.isEmpty()) {
            return ResponseEntity.badRequest().body("Missing or empty symbol or company name");
        }

        try {
            EquityPlotFetch action = getOrSaveUserStockAction(userType, userId, symbol, companyName, true);
            if (action != null) {
                return ResponseEntity.ok("Stock saved successfully");
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save stock");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving stock: " + e.getMessage());
        }
    }
}